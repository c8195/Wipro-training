﻿// SalesReport.cs
public class SalesReport : Report
{
    public override void GenerateHeader()
    {
        Content += "Sales Header\n";
    }

    public override void GenerateBody()
    {
        Content += "Sales Data\n";
    }
}