﻿using System;

namespace SOLIDReportingSystem
{
    public class PdfDocument : IDocument
    {
        public void Create()
        {
            Console.WriteLine("Creating a PDF document...");
        }

        public void Save()
        {
            Console.WriteLine("Saving PDF document...");
        }
    }
}
