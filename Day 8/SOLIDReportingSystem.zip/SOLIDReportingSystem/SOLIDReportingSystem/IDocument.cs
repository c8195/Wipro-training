﻿namespace SOLIDReportingSystem
{
    public interface IDocument
    {
        void Create();
        void Save();
    }
}
