﻿public class ReportSaver : IReportSaver
{
    public void SaveReport()
    {
        Console.WriteLine("Saving report...");
    }
}