export abstract class RouteComponent {}
