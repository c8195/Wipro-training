﻿using System;

namespace SOLIDReportingSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter document type (pdf/word): ");
            string docType = Console.ReadLine() ?? string.Empty;

            try
            {
                IDocument document = DocumentFactory.CreateDocument(docType);
                document.Create();
                document.Save();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            Console.WriteLine("Process completed.");

            // 👇 Keeps the console window open until Enter is pressed
        }
    }
}
