﻿public interface IReportSaver
{
    void SaveReport();
}