export * from './search.component'
