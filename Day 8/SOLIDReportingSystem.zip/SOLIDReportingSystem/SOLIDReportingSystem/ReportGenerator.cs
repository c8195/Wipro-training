﻿public class ReportGenerator : IReportGenerator
{
    public void GenerateReport()
    {
        Console.WriteLine("Generating report...");
    }
}