﻿// FinancialReport.cs
public class FinancialReport : Report
{
    public override void GenerateHeader()
    {
        Content += "Financial Header\n";
    }

    public override void GenerateBody()
    {
        Content += "Financial Data\n";
    }
}
