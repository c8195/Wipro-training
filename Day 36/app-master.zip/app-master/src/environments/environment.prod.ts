export const environment = {
  production: true,
  apiUrl: 'https://awesomehub.github.io/data/dist',
  ga: 'G-7BQJMP7YV8',
}
