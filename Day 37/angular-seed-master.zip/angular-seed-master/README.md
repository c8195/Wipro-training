# No longer under active maintenance

For starting a new project consider [Angular CLI](https://cli.angular.io). Read more [here](https://github.com/mgechev/angular-seed/issues/2416).
