﻿public interface IReportGenerator
{
    void GenerateReport();
}