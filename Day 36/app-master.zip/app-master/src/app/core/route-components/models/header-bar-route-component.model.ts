import { RouteComponent } from './route-component.model'

export abstract class HeaderBarRouteComponent extends RouteComponent {}
