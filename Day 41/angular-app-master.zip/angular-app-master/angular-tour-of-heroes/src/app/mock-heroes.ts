import { Hero } from './hero';

export const HEROES: Hero[] = [
	{ 'id': 11, name: 'Iron Man' },
	{ 'id': 12, name: 'Captain America' },
	{ 'id': 13, name: 'Hulk' },
	{ 'id': 14, name: 'Narco' },
	{ 'id': 15, name: 'Directory Fury' },
	{ 'id': 16, name: 'SHIELD' },
	{ 'id': 17, name: 'Flash' },
	{ 'id': 18, name: 'JARVIS' },
	{ 'id': 19, name: 'Thor' },
	{ 'id': 20, name: 'Loki' },
	{ 'id': 21, name: 'Dr. Banners' },
	{ 'id': 22, name: 'Iron Fist' },
]
