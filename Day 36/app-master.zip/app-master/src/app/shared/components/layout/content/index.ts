export * from './content.component'
