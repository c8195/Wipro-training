export interface Post{
    title:string,
    content:string,
    name:string,
    id:Date,
}