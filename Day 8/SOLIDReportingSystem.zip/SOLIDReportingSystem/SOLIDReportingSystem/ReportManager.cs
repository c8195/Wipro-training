﻿public class ReportManager
{
    public void GenerateReport()
    {
        Console.WriteLine("Generating report...");
        // Complex report generation logic
    }

    public void SaveReport()
    {
        Console.WriteLine("Saving report to file...");
        // File saving logic
    }
}