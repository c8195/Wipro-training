﻿using System;

namespace SOLIDReportingSystem
{
    public class WordDocument : IDocument
    {
        public void Create()
        {
            Console.WriteLine("Creating a Word document...");
        }

        public void Save()
        {
            Console.WriteLine("Saving Word document...");
        }
    }
}
