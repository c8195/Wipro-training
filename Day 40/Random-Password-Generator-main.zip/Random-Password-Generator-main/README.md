# RandomPasswordGenerator

This project generates a random strong Password of minimum 8 length and maximum 20 length.
The use of letters,digits and symbols depends upon the user.

# Live Site

Click [here](https://grraghav120.github.io/Random-Password-Generator/)

## Screenshots of project
![image](https://user-images.githubusercontent.com/96789493/232272329-8c0b54eb-eb97-4f25-bd1d-368911d9a68b.png)

![image](https://user-images.githubusercontent.com/96789493/232272340-ce686d3e-6ae5-46b5-96ee-de563431e426.png)


## Run the Project

- `npm start`
- Run `ng serve` for a dev server.
- Navigate to `http://localhost:4200/`.
- The application will automatically reload if you change any of the source files.

## Don't forget to give repo a star

