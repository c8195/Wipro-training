﻿// Report.cs
public abstract class Report
{
    protected string Content = "";

    public abstract void GenerateHeader();
    public abstract void GenerateBody();

    public string GetContent()
    {
        return Content;
    }
}
