export function myUtil() {
  // Code goes here
}
