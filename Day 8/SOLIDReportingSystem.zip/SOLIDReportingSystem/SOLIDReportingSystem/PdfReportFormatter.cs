﻿// PdfReportFormatter.cs
public class PdfReportFormatter : IReportFormatter
{
    public string Format(Report report)
    {
        return $"PDF formatted: {report.GetContent()}";
    }
}
