export * from './list-repo-score-style.diretive'
