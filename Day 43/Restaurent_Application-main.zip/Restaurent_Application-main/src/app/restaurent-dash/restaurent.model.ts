export class RestaurentData {
    id: number = 0;
    name: string = '';
    address: string = '';
    email: string = '';
    services: string = '';
    mobile: number = 0;
}