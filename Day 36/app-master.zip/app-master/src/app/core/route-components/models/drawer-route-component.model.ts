import { RouteComponent } from './route-component.model'

export abstract class DrawerRouteComponent extends RouteComponent {
  public abstract title: string
}
