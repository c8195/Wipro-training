## Project SS

## Home Page
![image](https://user-images.githubusercontent.com/96789493/229298354-2c361c4c-6a49-472e-85ba-ae08bb6a6661.png)

## Add Page
![image](https://user-images.githubusercontent.com/96789493/229298365-256bf281-50b1-46cb-8bd9-3adbfd4d4e18.png)

## Adding Page
![image](https://user-images.githubusercontent.com/96789493/229298423-ee0e02dc-2e93-4810-ba24-b46e021c020a.png)

## Post
![image](https://user-images.githubusercontent.com/96789493/229298442-b6f51e52-b49c-4fb4-b910-63d6735f59b7.png)

## Delete Post
![image](https://user-images.githubusercontent.com/96789493/229298468-55313340-0ca9-4df3-81d5-b3c97440a309.png)
 
