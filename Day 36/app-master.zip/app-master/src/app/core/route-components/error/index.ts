export * from './error404.component'
