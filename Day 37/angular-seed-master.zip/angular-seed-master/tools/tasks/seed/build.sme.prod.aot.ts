import { createSME } from '../../utils';

/**
 * Executes the build process, builds source-map-explorer report
 */
export = createSME('prod.aot');
