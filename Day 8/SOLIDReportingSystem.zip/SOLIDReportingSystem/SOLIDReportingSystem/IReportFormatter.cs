﻿public interface IReportFormatter
{
    string Format(Report report);
}